<?php
if (!defined('SGCE_INSTALLER')) { http_response_code(403); exit('Acceso directo no permitido.'); }

class InstalarMensajeUsuario extends Exception {}
class InstalarErrorSql extends Exception {}

function HInst($Texto) { return htmlspecialchars((string)$Texto, ENT_QUOTES, 'UTF-8'); }

function InstalarCadenaMayusculas($Texto) {
    $Texto = (string)$Texto;
    if (function_exists('mb_strtoupper')) { return mb_strtoupper($Texto, 'UTF-8'); }
    $Texto = strtr($Texto, ['á'=>'Á','é'=>'É','í'=>'Í','ó'=>'Ó','ú'=>'Ú','ü'=>'Ü','ñ'=>'Ñ']);
    return strtoupper($Texto);
}

function InstalarNormalizarMayusculas($Texto) {
    $Texto = trim(preg_replace('/\s+/u', ' ', (string)$Texto));
    return InstalarCadenaMayusculas($Texto);
}

function InstalarTurnosTextoSeguro($Texto) {
    $Turnos = [];
    foreach (preg_split('/[,;\n]+/u', (string)$Texto) as $Turno) {
        $Turno = InstalarNormalizarMayusculas($Turno);
        if ($Turno !== '' && preg_match('/^[0-9A-ZÁÉÍÓÚÜÑ ._\-\/]{1,40}$/u', $Turno) && !in_array($Turno, $Turnos, true)) {
            $Turnos[] = $Turno;
        }
    }
    return implode(PHP_EOL, $Turnos ?: ['MATUTINO','VESPERTINO']);
}


function InstalarCsrfToken() {
    if (empty($_SESSION['InstalarCsrfToken']) || !is_string($_SESSION['InstalarCsrfToken'])) {
        $_SESSION['InstalarCsrfToken'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['InstalarCsrfToken'];
}

function InstalarCampoCsrf() {
    return '<input type="hidden" name="InstalarCsrfToken" value="' . HInst(InstalarCsrfToken()) . '">';
}

function InstalarValidarCsrf($Token) {
    return is_string($Token) && isset($_SESSION['InstalarCsrfToken']) && hash_equals($_SESSION['InstalarCsrfToken'], $Token);
}

function InstalarModoDebug() {
    return getenv('SGCE_DEBUG_INSTALLER') === '1';
}
