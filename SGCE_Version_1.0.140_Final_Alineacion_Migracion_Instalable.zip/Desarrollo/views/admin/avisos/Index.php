<?php if (!defined('SGCE_APP')) { http_response_code(403); exit('Acceso directo no permitido.'); } ?>
<!DOCTYPE html>
<html lang="es">
<head>
<?= SgceLayoutHeadBase('SGCE | Avisos', $Pdo, [
    'assets/css/admin-paginacion-busqueda.css',
    'assets/css/avisos-botones-metalicos.css',
]) ?>
</head>
<body class="AvisosBody">

<main class="SgcePageWrap SgceModuleWrap AvisosWrap">

    <section class="SgceHero AvisosHero">
        <div class="SgceHeroInfo">
            <div class="SgceHeroIcon"><span class="SgceColorIcon" aria-hidden="true">📣</span></div>
            <div>
                <h1>AVISOS Y COMUNICADOS</h1>
                <p>Publica avisos para maestros, padres o todo el sistema.</p>
            </div>
        </div>
        <div class="SgceHeroActions">
            <a href="Admin.php?Tab=inicio" class="SgceBtnVolverInicio" title="Volver al inicio" aria-label="Volver al inicio"><i class="fa-solid fa-house"></i><span>Volver al inicio</span></a>
        </div>
    </section>

    <?php if (isset($_SESSION['Mensaje'])): ?>
        <div class="alert alert-<?= HAviso($_SESSION['MensajeTipo'] ?? 'success') ?> AlertAuto alert-dismissible fade show mb-4">
            <i class="fa-solid fa-circle-info me-2"></i>
            <?= HAviso($_SESSION['Mensaje']) ?>
            <?php unset($_SESSION['Mensaje'], $_SESSION['MensajeTipo']); ?>
            <button class="btn-close" data-bs-dismiss="alert" type="button" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>

    <section class="AvisosLayout">
        <div class="SgceCard AvisosFormCard">
            <div class="SgceCardHeaderLine">
                <div class="SgceMiniIcon"><span class="SgceColorIcon" aria-hidden="true">➕</span></div>
                <div>
                    <h2>NUEVO AVISO</h2>
                    <p>Captura un comunicado y define a quién se mostrará.</p>
                </div>
            </div>

            <form method="POST" class="AvisosForm">
                <?php echo CampoCsrf(); ?>
                <input type="hidden" name="CrearAviso" value="1">

                <label>TÍTULO</label>
                <input name="Titulo" class="form-control" required placeholder="TÍTULO DEL AVISO" autocomplete="off">

                <label>PÚBLICO</label>
                <select name="Publico" class="form-select">
                    <option value="TODOS">TODOS</option>
                    <option value="MAESTROS">MAESTROS</option>
                    <option value="PADRES">PADRES</option>
                </select>

                <label>MENSAJE</label>
                <textarea name="Mensaje" class="form-control" rows="6" required placeholder="ESCRIBE EL COMUNICADO"></textarea>

                <button id="BtnPublicarAvisoVerdeMetalico" class="SgceBtnVerdeMetalicoIndependiente" type="submit">
                    <i class="fa-solid fa-paper-plane"></i>
                    <span>PUBLICAR AVISO</span>
                </button>
            </form>
        </div>

        <div class="SgceCard AvisosTableCard">
            <div class="SgceCardHeaderLine AvisosTableHeader AvisosTableHeaderClean">
                <div class="SgceMiniIcon"><span class="SgceColorIcon" aria-hidden="true">📋</span></div>
                <div>
                    <h2>AVISOS REGISTRADOS</h2>
                </div>
            </div>

            <div class="table-responsive AvisosTableResponsive">
                <table class="table align-middle AvisosTable">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Título</th>
                            <th>Público</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($Avisos as $A): ?>
                            <?php
                                $AvisoId = (int)$A['Id'];
                                $EstaActivo = (int)$A['Activo'] === 1;
                            ?>
                            <tr>
                                <td class="AvisoFecha"><?= HAviso(date('d/m/Y H:i', strtotime($A['FechaCreacion']))) ?></td>
                                <td class="AvisoTituloTabla"><?= HAviso($A['Titulo']) ?></td>
                                <td><span class="BadgePublico"><?= HAviso($A['Publico']) ?></span></td>
                                <td>
                                    <span class="BadgeEstado <?= $EstaActivo ? '' : 'BadgeInactivo' ?>">
                                        <?= $EstaActivo ? 'ACTIVO' : 'INACTIVO' ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="AccionesAviso">
                                        <button type="button" class="ActionBtn BtnAvisoEdit" data-bs-toggle="modal" data-bs-target="#ModalEditarAviso<?= $AvisoId ?>">
                                            <i class="fa-solid fa-pen-to-square"></i><span>EDITAR</span>
                                        </button>

                                        <?php if ($EstaActivo): ?>
                                            <button type="button" class="ActionBtn BtnAvisoDeactivate" data-bs-toggle="modal" data-bs-target="#ModalDesactivarAviso<?= $AvisoId ?>">
                                                <i class="fa-solid fa-ban"></i><span>DESACTIVAR</span>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="ActionBtn BtnAvisoActivate" data-bs-toggle="modal" data-bs-target="#ModalActivarAviso<?= $AvisoId ?>">
                                                <i class="fa-solid fa-circle-check"></i><span>ACTIVAR</span>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (empty($Avisos)): ?>
                            <tr>
                                <td colspan="5" class="py-5 text-center text-muted fw-bold">SIN AVISOS REGISTRADOS.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?= SgceRenderPager('PagAvisos', $PaginaAvisos, $TotalAvisos, $PorPaginaAvisos) ?>
        </div>
    </section>
</main>
<?php foreach ($Avisos as $A): ?>
<?php
    $AvisoId = (int)$A['Id'];
    $EstaActivoModal = (int)$A['Activo'] === 1;
?>

<div class="modal fade" id="ModalEditarAviso<?= $AvisoId ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ModalEditarPro">
        <div class="modal-content EditModalContent">
            <form method="POST" class="m-0">
                <?php echo CampoCsrf(); ?>
                <input type="hidden" name="EditarAviso" value="1">
                <input type="hidden" name="AvisoId" value="<?= $AvisoId ?>">

                <div class="EditModalHeader">
                    <div class="EditIcon"><i class="fa-solid fa-pen-to-square"></i></div>
                    <h4>EDITAR AVISO</h4>
                    <p>Actualiza el comunicado seleccionado</p>
                </div>

                <div class="EditModalBody">
                    <div class="EditInfoBox">
                        <i class="fa-solid fa-circle-info me-2"></i>
                        LOS CAMBIOS SE GUARDARÁN AL CONFIRMAR.
                    </div>

                    <label>TÍTULO</label>
                    <input name="Titulo" class="form-control mb-3" required value="<?= HAviso($A['Titulo']) ?>">

                    <label>PÚBLICO</label>
                    <select name="Publico" class="form-select mb-3">
                        <option value="TODOS" <?= $A['Publico'] === 'TODOS' ? 'selected' : '' ?>>TODOS</option>
                        <option value="MAESTROS" <?= $A['Publico'] === 'MAESTROS' ? 'selected' : '' ?>>MAESTROS</option>
                        <option value="PADRES" <?= $A['Publico'] === 'PADRES' ? 'selected' : '' ?>>PADRES</option>
                    </select>

                    <label>MENSAJE</label>
                    <textarea name="Mensaje" class="form-control mb-3" rows="5" required><?= HAviso($A['Mensaje']) ?></textarea>

                    <div class="row g-2 mt-3">
                        <div class="col-md-6">
                            <button type="button" class="BtnCancelEdit" data-bs-dismiss="modal">
                                <i class="fa-solid fa-xmark"></i>
                                CANCELAR
                            </button>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="BtnSaveEdit BtnAvisoModalSave">
                                <i class="fa-solid fa-floppy-disk"></i>
                                GUARDAR CAMBIOS
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($EstaActivoModal): ?>
<div class="modal fade ModalAvisoEstado" id="ModalDesactivarAviso<?= $AvisoId ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm ModalEliminarFijo">
        <div class="modal-content DeleteModalContent AvisoConfirmContent">
            <div class="DeleteModalHeader AvisoConfirmHeader HeaderDesactivar">
                <div class="DeleteIcon"><i class="fa-solid fa-ban"></i></div>
                <h4 class="fw-bold mb-1">CONFIRMAR DESACTIVACIÓN</h4>
                <p class="mb-0 opacity-75">AVISO</p>
            </div>
            <div class="DeleteModalBody">
                <p class="fs-6 fw-bold mb-3">¿DESEAS DESACTIVAR ESTE AVISO?</p>
                <div class="AvisoTituloModal mb-3"><?= HAviso($A['Titulo']) ?></div>
                <div class="DeleteWarningBox mb-4">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i>
                    Revisa bien antes de confirmar. El aviso dejará de mostrarse, pero podrás activarlo después.
                </div>
                <form method="POST" class="m-0">
                    <?php echo CampoCsrf(); ?>
                    <div class="d-flex justify-content-center gap-2 flex-wrap">
                        <button type="button" class="BtnCancelDelete" data-bs-dismiss="modal"><i class="fa-solid fa-xmark"></i> CANCELAR</button>
                        <button name="DesactivarAviso" value="<?= $AvisoId ?>" type="submit" class="BtnConfirmDelete BtnConfirmDesactivar BtnAvisoModalDeactivate"><i class="fa-solid fa-ban"></i> SÍ, DESACTIVAR</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="modal fade ModalAvisoEstado" id="ModalActivarAviso<?= $AvisoId ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm ModalEliminarFijo">
        <div class="modal-content DeleteModalContent AvisoConfirmContent">
            <div class="DeleteModalHeader AvisoConfirmHeader HeaderActivar">
                <div class="DeleteIcon"><i class="fa-solid fa-circle-check"></i></div>
                <h4 class="fw-bold mb-1">CONFIRMAR ACTIVACIÓN</h4>
                <p class="mb-0 opacity-75">AVISO</p>
            </div>
            <div class="DeleteModalBody">
                <p class="fs-6 fw-bold mb-3">¿DESEAS ACTIVAR ESTE AVISO?</p>
                <div class="AvisoTituloModal mb-3"><?= HAviso($A['Titulo']) ?></div>
                <div class="DeleteWarningBox mb-4">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i>
                    Revisa bien antes de confirmar. El aviso volverá a mostrarse al público seleccionado.
                </div>
                <form method="POST" class="m-0">
                    <?php echo CampoCsrf(); ?>
                    <div class="d-flex justify-content-center gap-2 flex-wrap">
                        <button type="button" class="BtnCancelDelete" data-bs-dismiss="modal"><i class="fa-solid fa-xmark"></i> CANCELAR</button>
                        <button name="ActivarAviso" value="<?= $AvisoId ?>" type="submit" class="BtnConfirmDelete BtnConfirmActivar BtnAvisoModalActivate"><i class="fa-solid fa-circle-check"></i> SÍ, ACTIVAR</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; ?>
<?= SgceLayoutSharedJs(['assets/js/AvisosAdmin.js'], true, true) ?>
</body>
</html>
