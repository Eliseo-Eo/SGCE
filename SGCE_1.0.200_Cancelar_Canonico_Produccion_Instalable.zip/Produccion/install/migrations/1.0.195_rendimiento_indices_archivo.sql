-- SGCE 1.0.195 - rendimiento, archivado e indices
-- Ejecutar en instalaciones existentes despues de respaldo completo verificado.
-- No agrega particionado: MySQL/InnoDB no permite particionar tablas con llaves foraneas de usuario sin redisenar constraints.

CREATE TABLE IF NOT EXISTS AsistenciasArchivo LIKE Asistencias;

DELIMITER $$
DROP PROCEDURE IF EXISTS sgce_drop_index_if_exists $$
CREATE PROCEDURE sgce_drop_index_if_exists(IN p_table VARCHAR(64), IN p_index VARCHAR(64))
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND INDEX_NAME = p_index
        LIMIT 1
    ) THEN
        SET @sql = CONCAT('ALTER TABLE `', REPLACE(p_table, '`', '``'), '` DROP INDEX `', REPLACE(p_index, '`', '``'), '`');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END $$
DELIMITER ;

CALL sgce_drop_index_if_exists('Asistencias', 'idx_asistencias_fecha_asignacion_alumno');
CALL sgce_drop_index_if_exists('Asistencias', 'idx_asistencias_publica');
CALL sgce_drop_index_if_exists('Asistencias', 'idx_asistencias_estado_fecha');
CALL sgce_drop_index_if_exists('Asistencias', 'idx_asistencias_fecha_alumno_estado');

CALL sgce_drop_index_if_exists('AsistenciasArchivo', 'idx_asistencias_fecha_asignacion_alumno');
CALL sgce_drop_index_if_exists('AsistenciasArchivo', 'idx_asistencias_publica');
CALL sgce_drop_index_if_exists('AsistenciasArchivo', 'idx_asistencias_estado_fecha');
CALL sgce_drop_index_if_exists('AsistenciasArchivo', 'idx_asistencias_fecha_alumno_estado');

CALL sgce_drop_index_if_exists('Asignaciones', 'idx_asignaciones_materia');
CALL sgce_drop_index_if_exists('Asignaciones', 'idx_asignaciones_materia_grupo_id');

CALL sgce_drop_index_if_exists('Calificaciones', 'idx_calificaciones_periodo');
CALL sgce_drop_index_if_exists('Calificaciones', 'idx_calificaciones_alumno');
CALL sgce_drop_index_if_exists('Calificaciones', 'idx_calificaciones_valor');
CALL sgce_drop_index_if_exists('Calificaciones', 'idx_calificaciones_periodo_alumno_valor');

DROP PROCEDURE IF EXISTS sgce_drop_index_if_exists;
