-- SGCE 1.0.195 - decision tecnica sobre particionado
-- Este archivo es deliberadamente NO-OP.
-- No se aplica particionado automatico a Asistencias ni Calificaciones porque:
-- 1) Asistencias tiene llaves foraneas hacia CiclosEscolares, Asignaciones y Alumnos.
-- 2) Calificaciones tiene llaves foraneas y no posee CicloId fisico directo; su ciclo se deriva por PeriodoId.
-- 3) MySQL/InnoDB con particionado definido por usuario no permite mantener llaves foraneas en esas tablas.
-- 4) Quitar esas llaves para particionar seria un cambio estructural riesgoso y fuera de una entrega de rendimiento segura.
-- Alternativa aplicada en 1.0.195: tabla AsistenciasArchivo + cron de archivado de ciclos cerrados + indices consolidados.
SELECT 'SGCE 1.0.195: particionado no aplicado por compatibilidad con llaves foraneas; usar archivado seguro.' AS Nota;
