<?php
if (!defined('SGCE_INSTALLER')) { http_response_code(403); exit('Acceso directo no permitido.'); }

class InstalarMensajeUsuario extends Exception {}
class InstalarErrorSql extends Exception {}

function HInst($Texto) { return htmlspecialchars((string)$Texto, ENT_QUOTES, 'UTF-8'); }

function InstalarCadenaMayusculas($Texto) {
    $Texto = (string)$Texto;
    if (function_exists('mb_strtoupper')) { return mb_strtoupper($Texto, 'UTF-8'); }
    $Texto = strtr($Texto, ['á'=>'Á','é'=>'É','í'=>'Í','ó'=>'Ó','ú'=>'Ú','ü'=>'Ü','ñ'=>'Ñ']);
    return strtoupper($Texto);
}

function InstalarNormalizarMayusculas($Texto) {
    $Texto = trim(preg_replace('/\s+/u', ' ', (string)$Texto));
    return InstalarCadenaMayusculas($Texto);
}

function InstalarTurnosTextoSeguro($Texto) {
    $Turnos = [];
    foreach (preg_split('/[,;\n]+/u', (string)$Texto) as $Turno) {
        $Turno = InstalarNormalizarMayusculas($Turno);
        if ($Turno !== '' && preg_match('/^[0-9A-ZÁÉÍÓÚÜÑ ._\-\/]{1,40}$/u', $Turno) && !in_array($Turno, $Turnos, true)) {
            $Turnos[] = $Turno;
        }
    }
    return implode(PHP_EOL, $Turnos ?: ['MATUTINO','VESPERTINO']);
}


function InstalarCsrfCookiePath() {
    $Ruta = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return ($Ruta === '' || $Ruta === '.') ? '/' : $Ruta;
}

function InstalarCsrfCookieSecure() {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function InstalarCsrfTokenValidoFormato($Token) {
    return is_string($Token) && preg_match('/^[a-f0-9]{64}$/i', $Token) === 1;
}

function InstalarCsrfStorageDir() {
    return dirname(__DIR__, 2) . '/storage/locks';
}

function InstalarCsrfArchivoPath($Token) {
    return InstalarCsrfStorageDir() . '/installer_csrf_' . hash('sha256', strtolower((string)$Token)) . '.token';
}

function InstalarAsegurarCsrfStorage() {
    $Dir = InstalarCsrfStorageDir();
    if (!is_dir($Dir)) { @mkdir($Dir, 0775, true); }
    if (is_dir($Dir)) {
        $Htaccess = $Dir . '/.htaccess';
        if (!is_file($Htaccess)) {
            @file_put_contents($Htaccess, "Require all denied\nDeny from all\n");
        }
        $Index = $Dir . '/index.html';
        if (!is_file($Index)) { @file_put_contents($Index, ''); }
    }
    return is_dir($Dir) && is_writable($Dir);
}

function InstalarLimpiarCsrfArchivos() {
    $Dir = InstalarCsrfStorageDir();
    if (!is_dir($Dir)) { return; }
    $Limite = time() - 7200;
    foreach (glob($Dir . '/installer_csrf_*.token') ?: [] as $Archivo) {
        if (is_file($Archivo) && (@filemtime($Archivo) ?: 0) < $Limite) { @unlink($Archivo); }
    }
}

function InstalarPersistirCsrfArchivo($Token) {
    if (!InstalarCsrfTokenValidoFormato($Token) || !InstalarAsegurarCsrfStorage()) { return; }
    InstalarLimpiarCsrfArchivos();
    $Ruta = InstalarCsrfArchivoPath($Token);
    $Temporal = $Ruta . '.' . getmypid() . '.tmp';
    $Contenido = json_encode([
        'created_at' => time(),
        'token_hash' => hash('sha256', strtolower((string)$Token)),
    ], JSON_UNESCAPED_SLASHES);
    if ($Contenido === false) { return; }
    if (@file_put_contents($Temporal, $Contenido, LOCK_EX) !== false) {
        @chmod($Temporal, 0600);
        @rename($Temporal, $Ruta);
        @chmod($Ruta, 0600);
    } else {
        @unlink($Temporal);
    }
}

function InstalarValidarCsrfArchivo($Token) {
    if (!InstalarCsrfTokenValidoFormato($Token)) { return false; }
    $Ruta = InstalarCsrfArchivoPath($Token);
    if (!is_file($Ruta) || !is_readable($Ruta)) { return false; }
    if (((@filemtime($Ruta) ?: 0) + 7200) < time()) { @unlink($Ruta); return false; }

    $Datos = json_decode((string)@file_get_contents($Ruta), true);
    $HashEsperado = is_array($Datos) ? (string)($Datos['token_hash'] ?? '') : '';
    $HashRecibido = hash('sha256', strtolower((string)$Token));
    if ($HashEsperado !== '' && hash_equals($HashEsperado, $HashRecibido)) {
        $_SESSION['InstalarCsrfToken'] = (string)$Token;
        InstalarPersistirCsrfCookie((string)$Token);
        @touch($Ruta);
        return true;
    }
    return false;
}

function InstalarPersistirCsrfCookie($Token) {
    if (!InstalarCsrfTokenValidoFormato($Token)) { return; }
    InstalarPersistirCsrfArchivo($Token);
    if (headers_sent()) { return; }

    setcookie('SGCE_INSTALL_CSRF', $Token, [
        'expires' => 0,
        'path' => InstalarCsrfCookiePath(),
        'secure' => InstalarCsrfCookieSecure(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function InstalarCsrfToken() {
    if (!empty($_SESSION['InstalarCsrfToken']) && InstalarCsrfTokenValidoFormato($_SESSION['InstalarCsrfToken'])) {
        InstalarPersistirCsrfCookie($_SESSION['InstalarCsrfToken']);
        return $_SESSION['InstalarCsrfToken'];
    }

    if (!empty($_COOKIE['SGCE_INSTALL_CSRF']) && InstalarCsrfTokenValidoFormato($_COOKIE['SGCE_INSTALL_CSRF'])) {
        $_SESSION['InstalarCsrfToken'] = (string)$_COOKIE['SGCE_INSTALL_CSRF'];
        InstalarPersistirCsrfCookie($_SESSION['InstalarCsrfToken']);
        return $_SESSION['InstalarCsrfToken'];
    }

    $_SESSION['InstalarCsrfToken'] = bin2hex(random_bytes(32));
    InstalarPersistirCsrfCookie($_SESSION['InstalarCsrfToken']);
    return $_SESSION['InstalarCsrfToken'];
}

function InstalarCampoCsrf() {
    return '<input type="hidden" name="InstalarCsrfToken" value="' . HInst(InstalarCsrfToken()) . '">';
}

function InstalarValidarCsrf($Token) {
    if (!InstalarCsrfTokenValidoFormato($Token)) { return false; }

    if (!empty($_SESSION['InstalarCsrfToken']) && InstalarCsrfTokenValidoFormato($_SESSION['InstalarCsrfToken'])) {
        if (hash_equals((string)$_SESSION['InstalarCsrfToken'], (string)$Token)) { return true; }
    }

    if (!empty($_COOKIE['SGCE_INSTALL_CSRF']) && InstalarCsrfTokenValidoFormato($_COOKIE['SGCE_INSTALL_CSRF'])) {
        if (hash_equals((string)$_COOKIE['SGCE_INSTALL_CSRF'], (string)$Token)) { return true; }
    }

    return InstalarValidarCsrfArchivo((string)$Token);
}

function InstalarModoDebug() {
    return getenv('SGCE_DEBUG_INSTALLER') === '1';
}
