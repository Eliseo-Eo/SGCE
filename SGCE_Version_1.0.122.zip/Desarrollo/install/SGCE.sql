CREATE TABLE ConfiguracionSistema (
    Clave VARCHAR(80) NOT NULL PRIMARY KEY,
    Valor TEXT NULL,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_config_fecha (FechaActualizacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Usuarios (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(80) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    NombreCompleto VARCHAR(140) NOT NULL,
    NombreBusqueda VARCHAR(180) NOT NULL DEFAULT '',
    Rol ENUM('admin', 'administrativo', 'maestro') NOT NULL DEFAULT 'maestro',
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    SessionToken CHAR(64) DEFAULT NULL,
    SessionTokenExpira DATETIME DEFAULT NULL,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unico_username (Username),
    INDEX idx_usuarios_session_token (SessionToken),
    INDEX idx_usuarios_session_expira (SessionTokenExpira),
    INDEX idx_usuarios_rol_activo_nombre (Rol, Activo, NombreCompleto),
    INDEX idx_usuarios_nombre (NombreCompleto),
    INDEX idx_usuarios_nombre_busqueda (NombreBusqueda),
    FULLTEXT KEY ft_usuarios_busqueda (NombreBusqueda, NombreCompleto),
    INDEX idx_usuarios_activo (Activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE CiclosEscolares (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(40) NOT NULL,
    FechaInicio DATE NOT NULL,
    FechaFin DATE NOT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    ActivoUnico TINYINT GENERATED ALWAYS AS (CASE WHEN Activo = 1 THEN 1 ELSE NULL END) STORED,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unico_ciclo_nombre (Nombre),
    UNIQUE KEY unico_ciclo_activo (ActivoUnico),
    INDEX idx_ciclos_activo_fecha (Activo, FechaInicio, FechaFin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE OfertasEducativas (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(140) NOT NULL,
    NivelEducativo ENUM('PRIMARIA','SECUNDARIA','BACHILLERATO','UNIVERSIDAD','MAESTRIA','DOCTORADO','CURSO') NOT NULL DEFAULT 'SECUNDARIA',
    TipoPeriodizacion ENUM('ANUAL','SEMESTRAL','CUATRIMESTRAL','TRIMESTRAL','MODULAR') NOT NULL DEFAULT 'ANUAL',
    TotalEtapas INT UNSIGNED NOT NULL DEFAULT 3,
    EtiquetaEtapa VARCHAR(40) NOT NULL DEFAULT 'GRADO',
    UsaProgramas TINYINT(1) NOT NULL DEFAULT 0,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unico_oferta_nombre (Nombre),
    INDEX idx_oferta_activa (Activo, NivelEducativo, TipoPeriodizacion),
    INDEX idx_oferta_nivel_periodizacion (NivelEducativo, TipoPeriodizacion, Activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ConfiguracionesAcademicas (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    OfertaId INT UNSIGNED NOT NULL,
    CantidadPeriodosEvaluacion INT UNSIGNED NOT NULL DEFAULT 3,
    NombreBasePeriodo VARCHAR(60) NOT NULL DEFAULT 'PARCIAL',
    ModoPeriodos ENUM('AUTOMATICO','PERSONALIZADO') NOT NULL DEFAULT 'AUTOMATICO',
    PeriodosPersonalizados TEXT DEFAULT NULL,
    UsaPlaneaciones TINYINT(1) NOT NULL DEFAULT 1,
    TipoPlaneacion ENUM('CICLO','PERIODO','UNIDAD','SEMANA') NOT NULL DEFAULT 'CICLO',
    PlaneacionesCantidad INT UNSIGNED NOT NULL DEFAULT 1,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_config_academica_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_config_academica_oferta (OfertaId),
    INDEX idx_config_academica_activa (Activo, OfertaId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ProgramasEducativos (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    OfertaId INT UNSIGNED NOT NULL,
    Nombre VARCHAR(160) NOT NULL,
    Clave VARCHAR(30) DEFAULT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_programas_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_programa_oferta_nombre (OfertaId, Nombre),
    INDEX idx_programas_activo_nombre (Activo, Nombre),
    INDEX idx_programas_oferta_activo (OfertaId, Activo, Nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE EtapasAcademicas (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    OfertaId INT UNSIGNED NOT NULL,
    Nombre VARCHAR(40) NOT NULL,
    Orden INT UNSIGNED NOT NULL,
    EsTerminal TINYINT(1) NOT NULL DEFAULT 0,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_etapas_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_etapa_oferta_orden (OfertaId, Orden),
    UNIQUE KEY unico_etapa_oferta_nombre (OfertaId, Nombre),
    INDEX idx_etapas_oferta_activa_orden (OfertaId, Activo, Orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Grupos (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    OfertaId INT UNSIGNED NOT NULL,
    ProgramaId INT UNSIGNED NOT NULL,
    EtapaId INT UNSIGNED NOT NULL,
    Grado VARCHAR(40) NOT NULL,
    Grupo VARCHAR(10) NOT NULL,
    Turno VARCHAR(40) NOT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_grupos_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_grupos_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_grupos_programa FOREIGN KEY (ProgramaId) REFERENCES ProgramasEducativos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_grupos_etapa FOREIGN KEY (EtapaId) REFERENCES EtapasAcademicas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_grupo_estructura (CicloId, OfertaId, ProgramaId, EtapaId, Grupo, Turno),
    INDEX idx_grupos_busqueda_publica (CicloId, Grado, Grupo, Turno, Activo),
    INDEX idx_grupos_orden (CicloId, Activo, Turno, Grado, Grupo, Id),
    INDEX idx_grupos_ciclo (CicloId, Activo),
    INDEX idx_grupos_estructura (CicloId, OfertaId, ProgramaId, EtapaId, Turno, Grupo, Activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Alumnos (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    NombreCompleto VARCHAR(160) NOT NULL,
    NombreBusqueda VARCHAR(200) NOT NULL DEFAULT '',
    Matricula VARCHAR(40) DEFAULT NULL,
    AnioIngreso SMALLINT UNSIGNED DEFAULT NULL,
    GrupoId INT UNSIGNED DEFAULT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_alumnos_grupos FOREIGN KEY (GrupoId) REFERENCES Grupos(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY unico_alumno_grupo (NombreCompleto, GrupoId),
    UNIQUE KEY unico_alumno_matricula (Matricula),
    INDEX idx_alumnos_grupo_nombre_id (GrupoId, NombreCompleto, Id),
    INDEX idx_alumnos_busqueda_publica (GrupoId, NombreCompleto, Activo),
    INDEX idx_alumnos_nombre (NombreCompleto),
    INDEX idx_alumnos_nombre_busqueda (NombreBusqueda),
    FULLTEXT KEY ft_alumnos_busqueda (NombreBusqueda, NombreCompleto),
    INDEX idx_alumnos_activo_grupo_nombre (Activo, GrupoId, NombreCompleto, Id),
    INDEX idx_alumnos_activo (Activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE AlumnoInscripciones (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    AlumnoId INT UNSIGNED NOT NULL,
    CicloId INT UNSIGNED NOT NULL,
    GrupoId INT UNSIGNED NOT NULL,
    OfertaId INT UNSIGNED NOT NULL,
    ProgramaId INT UNSIGNED NOT NULL,
    EtapaId INT UNSIGNED NOT NULL,
    Estado ENUM('INSCRITO','PROMOVIDO','EGRESADO','BAJA') NOT NULL DEFAULT 'INSCRITO',
    FechaInscripcion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_inscripciones_alumno FOREIGN KEY (AlumnoId) REFERENCES Alumnos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_inscripciones_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_inscripciones_grupo FOREIGN KEY (GrupoId) REFERENCES Grupos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_inscripciones_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_inscripciones_programa FOREIGN KEY (ProgramaId) REFERENCES ProgramasEducativos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_inscripciones_etapa FOREIGN KEY (EtapaId) REFERENCES EtapasAcademicas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_alumno_ciclo (AlumnoId, CicloId),
    INDEX idx_inscripciones_ciclo_grupo_estado (CicloId, GrupoId, Estado, AlumnoId),
    INDEX idx_inscripciones_alumno_ciclo (AlumnoId, CicloId),
    INDEX idx_inscripciones_grupo_estado (GrupoId, Estado),
    INDEX idx_inscripciones_estructura (CicloId, OfertaId, ProgramaId, EtapaId, Estado, GrupoId, AlumnoId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE MateriasCatalogo (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(140) NOT NULL,
    NombreBusqueda VARCHAR(180) NOT NULL DEFAULT '',
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unico_materia_nombre (Nombre),
    INDEX idx_materias_activo_nombre (Activo, Nombre),
    INDEX idx_materias_nombre_busqueda (NombreBusqueda),
    FULLTEXT KEY ft_materias_catalogo_busqueda (NombreBusqueda, Nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE MateriasGrupo (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    OfertaId INT UNSIGNED NOT NULL,
    ProgramaId INT UNSIGNED NOT NULL,
    EtapaId INT UNSIGNED NOT NULL,
    GrupoId INT UNSIGNED NOT NULL,
    MateriaId INT UNSIGNED NOT NULL,
    MateriaNombre VARCHAR(140) NOT NULL,
    MateriaBusqueda VARCHAR(180) NOT NULL DEFAULT '',
    HorasSemana TINYINT UNSIGNED NOT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_materias_grupo_horas CHECK (HorasSemana >= 1 AND HorasSemana <= 40),
    CONSTRAINT fk_materias_grupo_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_materias_grupo_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_materias_grupo_programa FOREIGN KEY (ProgramaId) REFERENCES ProgramasEducativos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_materias_grupo_etapa FOREIGN KEY (EtapaId) REFERENCES EtapasAcademicas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_materias_grupo_grupo FOREIGN KEY (GrupoId) REFERENCES Grupos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_materias_grupo_catalogo FOREIGN KEY (MateriaId) REFERENCES MateriasCatalogo(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_materia_por_grupo (CicloId, GrupoId, MateriaId),
    INDEX idx_materias_grupo_ciclo_grupo (CicloId, GrupoId, Activo, MateriaNombre),
    INDEX idx_materias_grupo_estructura (CicloId, OfertaId, ProgramaId, EtapaId, GrupoId, Activo),
    INDEX idx_materias_grupo_catalogo (MateriaId, Activo),
    INDEX idx_materias_grupo_busqueda (CicloId, Activo, MateriaBusqueda, GrupoId),
    FULLTEXT KEY ft_materiasgrupo_busqueda (MateriaBusqueda, MateriaNombre),
    INDEX idx_materias_grupo_horas (CicloId, GrupoId, HorasSemana)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Asignaciones (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    MaestroId INT UNSIGNED NOT NULL,
    GrupoId INT UNSIGNED NOT NULL,
    MateriaGrupoId INT UNSIGNED NOT NULL,
    MateriaId INT UNSIGNED NOT NULL,
    MateriaNombre VARCHAR(140) NOT NULL,
    MateriaBusqueda VARCHAR(180) NOT NULL DEFAULT '',
    HorasSemana TINYINT UNSIGNED NOT NULL,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_asignaciones_horas CHECK (HorasSemana >= 1 AND HorasSemana <= 40),
    CONSTRAINT fk_asignaciones_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asignaciones_maestros FOREIGN KEY (MaestroId) REFERENCES Usuarios(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asignaciones_grupos FOREIGN KEY (GrupoId) REFERENCES Grupos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asignaciones_materia_grupo FOREIGN KEY (MateriaGrupoId) REFERENCES MateriasGrupo(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asignaciones_materia_catalogo FOREIGN KEY (MateriaId) REFERENCES MateriasCatalogo(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unica_asignacion_materia_grupo (MateriaGrupoId),
    UNIQUE KEY unica_materia_grupo_ciclo (CicloId, GrupoId, MateriaId),
    INDEX idx_asignaciones_maestro (CicloId, MaestroId, Activo),
    INDEX idx_asignaciones_grupo (CicloId, GrupoId, Activo),
    INDEX idx_asignaciones_grupo_id (GrupoId, Id, Activo),
    INDEX idx_asignaciones_grupo_materia (CicloId, GrupoId, MateriaId, MaestroId),
    INDEX idx_asignaciones_activo_maestro_grupo_materia (CicloId, Activo, MaestroId, GrupoId, MateriaNombre, Id),
    INDEX idx_asignaciones_materia (MateriaNombre),
    INDEX idx_asignaciones_materia_busqueda (CicloId, Activo, MateriaBusqueda),
    FULLTEXT KEY ft_asignaciones_busqueda (MateriaBusqueda, MateriaNombre),
    INDEX idx_asignaciones_materia_id (MateriaId),
    INDEX idx_asignaciones_materia_grupo_id (MateriaGrupoId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE PeriodosEvaluacion (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    OfertaId INT UNSIGNED NOT NULL,
    Nombre VARCHAR(80) NOT NULL,
    Orden INT UNSIGNED NOT NULL DEFAULT 1,
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_periodos_ciclos FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_periodos_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_periodo_ciclo_oferta_nombre (CicloId, OfertaId, Nombre),
    UNIQUE KEY unico_periodo_ciclo_oferta_orden (CicloId, OfertaId, Orden),
    INDEX idx_periodos_ciclo_oferta_orden (CicloId, OfertaId, Activo, Orden),
    INDEX idx_periodos_ciclo_orden (CicloId, Activo, Orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Calificaciones (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    AlumnoId INT UNSIGNED NOT NULL,
    AsignacionId INT UNSIGNED NOT NULL,
    PeriodoId INT UNSIGNED NOT NULL,
    Calificacion DECIMAL(5,2) NOT NULL,
    CONSTRAINT chk_calificaciones_rango CHECK (Calificacion >= 0 AND Calificacion <= 100),
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_calificaciones_alumnos FOREIGN KEY (AlumnoId) REFERENCES Alumnos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_calificaciones_asignaciones FOREIGN KEY (AsignacionId) REFERENCES Asignaciones(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_calificaciones_periodos FOREIGN KEY (PeriodoId) REFERENCES PeriodosEvaluacion(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_alumno_asignacion_periodo (AlumnoId, AsignacionId, PeriodoId),
    INDEX idx_calificaciones_asignacion (AsignacionId, AlumnoId),
    INDEX idx_calificaciones_periodo (PeriodoId, AsignacionId, AlumnoId),
    INDEX idx_calificaciones_alumno (AlumnoId, AsignacionId),
    INDEX idx_calificaciones_valor (Calificacion),
    INDEX idx_calificaciones_periodo_asignacion_alumno_valor (PeriodoId, AsignacionId, AlumnoId, Calificacion),
    INDEX idx_calificaciones_periodo_alumno_valor (PeriodoId, AlumnoId, Calificacion),
    INDEX idx_calificaciones_alumno_periodo (AlumnoId, PeriodoId, AsignacionId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Asistencias (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    AsignacionId INT UNSIGNED NOT NULL,
    AlumnoId INT UNSIGNED NOT NULL,
    Fecha DATETIME NOT NULL,
    FechaDia DATE GENERATED ALWAYS AS (DATE(Fecha)) STORED,
    Estado ENUM('A', 'F', 'R', 'J') NOT NULL,
    FechaRegistro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_asistencias_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asistencias_asignaciones FOREIGN KEY (AsignacionId) REFERENCES Asignaciones(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_asistencias_alumnos FOREIGN KEY (AlumnoId) REFERENCES Alumnos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    UNIQUE KEY unico_pase_lista (CicloId, AsignacionId, AlumnoId, FechaDia),
    INDEX idx_asistencias_asignacion_fecha_alumno (CicloId, AsignacionId, FechaDia, AlumnoId),
    INDEX idx_asistencias_alumno_fecha_asignacion (CicloId, AlumnoId, FechaDia, AsignacionId),
    INDEX idx_asistencias_fecha_asignacion_alumno (CicloId, FechaDia, AsignacionId, AlumnoId),
    INDEX idx_asistencias_publica (CicloId, AlumnoId, FechaDia, Estado, AsignacionId),
    INDEX idx_asistencias_estado_fecha (CicloId, Estado, FechaDia),
    INDEX idx_asistencias_fecha_estado (CicloId, FechaDia, Estado),
    INDEX idx_asistencias_rango_reporte (CicloId, FechaDia, AsignacionId, Estado, AlumnoId),
    INDEX idx_asistencias_fecha_alumno_estado (CicloId, FechaDia, AlumnoId, Estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE AsignacionDocenteHistorial (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    AsignacionId INT UNSIGNED NOT NULL,
    MaestroId INT UNSIGNED NOT NULL,
    FechaInicio DATETIME NULL,
    FechaFin DATETIME NULL,
    TipoMovimiento ENUM('TITULAR','INTERINATO','RELEVO') NOT NULL DEFAULT 'TITULAR',
    Motivo VARCHAR(255) DEFAULT NULL,
    RegistradoPor INT UNSIGNED DEFAULT NULL,
    FechaRegistro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_hist_asignacion FOREIGN KEY (AsignacionId) REFERENCES Asignaciones(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_hist_maestro FOREIGN KEY (MaestroId) REFERENCES Usuarios(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_hist_registrado_por FOREIGN KEY (RegistradoPor) REFERENCES Usuarios(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_hist_asignacion_fechas (AsignacionId, FechaInicio, FechaFin),
    INDEX idx_hist_maestro (MaestroId, FechaInicio, FechaFin),
    INDEX idx_hist_activo (AsignacionId, FechaFin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE KardexAlumno (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    AlumnoId INT UNSIGNED NOT NULL,
    CicloId INT UNSIGNED NOT NULL,
    GrupoId INT UNSIGNED NOT NULL,
    CicloNombreSnapshot VARCHAR(40) NOT NULL,
    GradoSnapshot VARCHAR(40) NOT NULL,
    GrupoSnapshot VARCHAR(10) NOT NULL,
    TurnoSnapshot VARCHAR(40) NOT NULL,
    OfertaNombreSnapshot VARCHAR(140) DEFAULT NULL,
    ProgramaNombreSnapshot VARCHAR(160) DEFAULT NULL,
    EtapaNombreSnapshot VARCHAR(40) DEFAULT NULL,
    EstadoFinal ENUM('INSCRITO','PROMOVIDO','EGRESADO','BAJA') NOT NULL DEFAULT 'INSCRITO',
    PromedioFinal DECIMAL(5,2) DEFAULT NULL,
    GeneradoPor INT UNSIGNED DEFAULT NULL,
    FechaGeneracion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_kardex_alumno FOREIGN KEY (AlumnoId) REFERENCES Alumnos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_kardex_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_kardex_grupo FOREIGN KEY (GrupoId) REFERENCES Grupos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_kardex_generado_por FOREIGN KEY (GeneradoPor) REFERENCES Usuarios(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY unico_kardex_alumno_ciclo (AlumnoId, CicloId),
    INDEX idx_kardex_alumno_ciclo (AlumnoId, CicloId),
    INDEX idx_kardex_ciclo_grupo (CicloId, GrupoId),
    INDEX idx_kardex_ciclo_alumno_estado (CicloId, AlumnoId, EstadoFinal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE KardexDetalle (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    KardexId BIGINT UNSIGNED NOT NULL,
    MateriaNombreSnapshot VARCHAR(140) NOT NULL,
    MaestroNombreSnapshot VARCHAR(140) DEFAULT NULL,
    CalificacionesJson TEXT NOT NULL,
    Promedio DECIMAL(5,2) DEFAULT NULL,
    Orden INT UNSIGNED NOT NULL DEFAULT 1,
    CONSTRAINT fk_kardex_detalle FOREIGN KEY (KardexId) REFERENCES KardexAlumno(Id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_kardex_detalle_kardex_orden (KardexId, Orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE MigracionesCiclo (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    TipoMigracion ENUM('GRUPO','CICLO') NOT NULL DEFAULT 'CICLO',
    CicloOrigenId INT UNSIGNED NOT NULL,
    CicloDestinoId INT UNSIGNED NOT NULL,
    GrupoOrigenId INT UNSIGNED NOT NULL DEFAULT 0,
    UsuarioId INT UNSIGNED DEFAULT NULL,
    Estado ENUM('EN_PROCESO','COMPLETADA','ERROR','SIMULADA') NOT NULL DEFAULT 'EN_PROCESO',
    Confirmacion VARCHAR(140) DEFAULT NULL,
    RespaldoRuta VARCHAR(255) DEFAULT NULL,
    HuellaCompletada VARCHAR(160) DEFAULT NULL,
    GruposProcesados INT UNSIGNED NOT NULL DEFAULT 0,
    GruposCreados INT UNSIGNED NOT NULL DEFAULT 0,
    AlumnosPromovidos INT UNSIGNED NOT NULL DEFAULT 0,
    AlumnosEgresados INT UNSIGNED NOT NULL DEFAULT 0,
    AlumnosOmitidos INT UNSIGNED NOT NULL DEFAULT 0,
    Conflictos INT UNSIGNED NOT NULL DEFAULT 0,
    KardexCongelados INT UNSIGNED NOT NULL DEFAULT 0,
    AsignacionesCopiadas INT UNSIGNED NOT NULL DEFAULT 0,
    AsignacionesOmitidas INT UNSIGNED NOT NULL DEFAULT 0,
    ResumenJson LONGTEXT DEFAULT NULL,
    Mensaje TEXT DEFAULT NULL,
    FechaInicio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaFin DATETIME DEFAULT NULL,
    CONSTRAINT fk_migraciones_ciclo_origen FOREIGN KEY (CicloOrigenId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_migraciones_ciclo_destino FOREIGN KEY (CicloDestinoId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_migraciones_usuario FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_migraciones_estado_fecha (Estado, FechaInicio),
    INDEX idx_migraciones_origen_destino (CicloOrigenId, CicloDestinoId, TipoMigracion, GrupoOrigenId, Estado),
    UNIQUE KEY uk_migraciones_completadas (HuellaCompletada),
    INDEX idx_migraciones_usuario_fecha (UsuarioId, FechaInicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE Avisos (
    Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Titulo VARCHAR(160) NOT NULL,
    Mensaje TEXT NOT NULL,
    Publico ENUM('TODOS', 'MAESTROS', 'PADRES') NOT NULL DEFAULT 'TODOS',
    Activo TINYINT(1) NOT NULL DEFAULT 1,
    FechaCreacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_avisos_activo_fecha (Activo, FechaCreacion),
    INDEX idx_avisos_publico_activo_fecha (Publico, Activo, FechaCreacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Planeaciones (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CicloId INT UNSIGNED NOT NULL,
    OfertaId INT UNSIGNED NOT NULL,
    PeriodoId INT UNSIGNED DEFAULT NULL,
    ProgramaId INT UNSIGNED NOT NULL,
    MaestroId INT UNSIGNED NOT NULL,
    MateriaNombre VARCHAR(140) NOT NULL,
    Numero INT UNSIGNED NOT NULL,
    TipoPlaneacion ENUM('CICLO','PERIODO','UNIDAD','SEMANA') NOT NULL DEFAULT 'CICLO',
    VersionArchivo INT UNSIGNED NOT NULL DEFAULT 1,
    Titulo VARCHAR(180) DEFAULT NULL,
    ArchivoOriginal VARCHAR(255) NOT NULL,
    ArchivoGuardado VARCHAR(255) NOT NULL,
    MimeType VARCHAR(120) DEFAULT NULL,
    TamanoBytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    Estado ENUM('SUBIDA','APROBADA','DEVUELTA') NOT NULL DEFAULT 'SUBIDA',
    NotaRevision TEXT DEFAULT NULL,
    RevisadoPor INT UNSIGNED DEFAULT NULL,
    FechaRevision DATETIME DEFAULT NULL,
    FechaSubida TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_planeaciones_ciclo FOREIGN KEY (CicloId) REFERENCES CiclosEscolares(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_planeaciones_oferta FOREIGN KEY (OfertaId) REFERENCES OfertasEducativas(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_planeaciones_programa FOREIGN KEY (ProgramaId) REFERENCES ProgramasEducativos(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_planeaciones_periodo FOREIGN KEY (PeriodoId) REFERENCES PeriodosEvaluacion(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_planeaciones_maestro FOREIGN KEY (MaestroId) REFERENCES Usuarios(Id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_planeaciones_revisor FOREIGN KEY (RevisadoPor) REFERENCES Usuarios(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY unico_planeacion_docente_materia_numero (CicloId, OfertaId, ProgramaId, MaestroId, MateriaNombre, Numero),
    INDEX idx_planeaciones_maestro_ciclo (MaestroId, CicloId, ProgramaId, MateriaNombre, Numero),
    INDEX idx_planeaciones_estado (Estado, FechaActualizacion),
    INDEX idx_planeaciones_numero (Numero),
    INDEX idx_planeaciones_modelo_academico (CicloId, OfertaId, ProgramaId, PeriodoId, TipoPlaneacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE BitacoraMovimientos (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    UsuarioId INT UNSIGNED DEFAULT NULL,
    Rol VARCHAR(30) DEFAULT NULL,
    Accion VARCHAR(80) NOT NULL,
    TablaAfectada VARCHAR(80) DEFAULT NULL,
    RegistroId BIGINT UNSIGNED DEFAULT NULL,
    Detalle TEXT DEFAULT NULL,
    BusquedaTexto VARCHAR(500) NOT NULL DEFAULT '',
    Ip VARCHAR(45) DEFAULT NULL,
    FechaRegistro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bitacora_usuario FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_bitacora_fecha (FechaRegistro),
    INDEX idx_bitacora_usuario_fecha (UsuarioId, FechaRegistro),
    INDEX idx_bitacora_accion_fecha (Accion, FechaRegistro),
    INDEX idx_bitacora_fecha_id (FechaRegistro, Id),
    INDEX idx_bitacora_busqueda (FechaRegistro, Accion, UsuarioId),
    INDEX idx_bitacora_tabla_registro (TablaAfectada, RegistroId),
    FULLTEXT KEY ft_bitacora_busqueda (BusquedaTexto, Accion, TablaAfectada, Detalle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE BitacoraMovimientosArchivo LIKE BitacoraMovimientos;

CREATE TABLE IntentosSeguridad (
    Id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ClaveHash CHAR(64) NOT NULL,
    Contexto VARCHAR(40) NOT NULL,
    Intentos INT UNSIGNED NOT NULL DEFAULT 0,
    BloqueadoHasta DATETIME DEFAULT NULL,
    UltimoIntento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unico_contexto_clave (Contexto, ClaveHash),
    INDEX idx_intentos_bloqueado (Contexto, BloqueadoHasta),
    INDEX idx_intentos_ultimo (UltimoIntento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
